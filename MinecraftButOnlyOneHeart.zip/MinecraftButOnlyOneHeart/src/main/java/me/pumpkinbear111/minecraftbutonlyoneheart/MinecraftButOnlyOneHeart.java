package me.pumpkinbear111.minecraftbutonlyoneheart;

import me.pumpkinbear111.minecraftbutonlyoneheart.events.PlayerJoin;
import me.pumpkinbear111.minecraftbutonlyoneheart.events.WIN;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.event.EventHandler;
import org.bukkit.plugin.java.JavaPlugin;

public final class MinecraftButOnlyOneHeart extends JavaPlugin {

    @Override
    public void onEnable() {
        // Plugin startup logic
        System.out.println("Minecraft, But you only have one heart... has been enabled!");
        Bukkit.broadcastMessage(org.bukkit.Color.AQUA + "Welcome to " + org.bukkit.Color.RED + "MINECRAFT BUT: YOU ONLY HAVE ONE HEART." + Color.GRAY + "If you experience any problems, feel free to comment on our spigot page, and subscribe to PumpkinBear111 on YouTube to support future plugin development");

        getServer().getPluginManager().registerEvents(new PlayerJoin(), this);
        getServer().getPluginManager().registerEvents(new WIN(), this);


    }

    @Override
    public void onDisable() {
        // Plugin shutdown logic
        System.out.println("Minecraft, But you only have one heart... has been disabled.");
    }


}
