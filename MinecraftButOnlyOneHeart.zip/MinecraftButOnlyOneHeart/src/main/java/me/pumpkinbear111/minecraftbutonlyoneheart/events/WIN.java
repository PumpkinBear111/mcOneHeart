package me.pumpkinbear111.minecraftbutonlyoneheart.events;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.advancement.Advancement;
import org.bukkit.attribute.Attribute;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerAdvancementDoneEvent;
import org.bukkit.event.server.BroadcastMessageEvent;
import org.bukkit.inventory.ItemStack;

import java.util.concurrent.TimeUnit;

public class WIN implements Listener {

    @EventHandler
    public void Advancement(PlayerAdvancementDoneEvent e) {

        if(e.getAdvancement().getKey().toString().equals("minecraft:end/kill_dragon")) {

            Bukkit.broadcastMessage(ChatColor.RED + "WHAT!");
            Bukkit.broadcastMessage(ChatColor.DARK_GREEN + "MY BRAIN!!!");
            Bukkit.broadcastMessage(ChatColor.YELLOW + "How?");
            Bukkit.broadcastMessage(ChatColor.YELLOW + "You had one heart.");
            Bukkit.broadcastMessage(ChatColor.YELLOW + "HOW DID YOU DO IT BRUHH");
            Bukkit.broadcastMessage(ChatColor.YELLOW + "You " + ChatColor.RED + "defeated " + ChatColor.YELLOW + "the " + ChatColor.BOLD + ChatColor.DARK_PURPLE + "ENDER DRAGON" + ChatColor.RESET + ChatColor.YELLOW + " with 1 heart!!!");
            Bukkit.broadcastMessage(ChatColor.YELLOW + "You are the true god of MineCraft.");
            Bukkit.broadcastMessage(ChatColor.AQUA + "Here ya go,");
            Bukkit.broadcastMessage(ChatColor.GREEN + "YOU DESERVE IT.");

            e.getPlayer().giveExpLevels(1000000);
            e.getPlayer().setAllowFlight(true);
            Bukkit.broadcastMessage(ChatColor.GRAY + "Flight has been enabled for" + e.getPlayer().getDisplayName());

            e.getPlayer().getAttribute(Attribute.GENERIC_MAX_HEALTH).setBaseValue(20);
            e.getPlayer().setHealth(20);
            e.getPlayer().setFoodLevel(20);



        }

    }



}
