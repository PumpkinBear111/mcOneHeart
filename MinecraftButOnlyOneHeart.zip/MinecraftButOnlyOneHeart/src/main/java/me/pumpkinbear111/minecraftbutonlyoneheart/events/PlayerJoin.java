package me.pumpkinbear111.minecraftbutonlyoneheart.events;

import org.bukkit.ChatColor;
import org.bukkit.Color;
import org.bukkit.attribute.Attribute;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.event.player.PlayerJoinEvent;

public class PlayerJoin implements Listener {

    @EventHandler
    public void PlayerJoinServer(PlayerJoinEvent joinE) {

        joinE.setJoinMessage(ChatColor.RED + "Did you know you only have one heart " + ChatColor.DARK_PURPLE + joinE.getPlayer().getDisplayName());
        //joinE.getPlayer().setFoodLevel(8);

        joinE.getPlayer().getAttribute(Attribute.GENERIC_MAX_HEALTH).setBaseValue(2);



    }








}
